import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.awt.Image;
import java.awt.image.CropImageFilter;
import java.awt.image.FilteredImageSource;

public class PuzzleGame extends JFrame {
    final int HEIGHT = 400; // keep the height
    int WIDTH = 100; // allow the width to be resized
    int NUMROWS = 4;
    int NUMCOLS = 3;
    JPanel mainPanel = new JPanel();
    ArrayList<FancyButton> allButtons = new ArrayList<FancyButton>();// will store references to the buttons
    BufferedImage imageSource; // holds the original image
    BufferedImage imageResized; // holds the original image shrinked to desired width/height?
    JMenuBar menuBar = new JMenuBar();
    JMenu optionMenu = new JMenu("Settings!");
    JMenuItem numRowsItem = new JMenuItem("Set number of rows");
    JMenuItem numColsItem = new JMenuItem("Set number of columns");
    JButton resetButton = new JButton("Reset");

    public void ClickEventHandler(ActionEvent e) {
        // which button was clicked on?
        FancyButton btnClicked = (FancyButton) e.getSource();

        // WHAT'S THE BUTTON THAT WAS CLICKED?
        int i = allButtons.indexOf(btnClicked); // which button in the list
        int row = i / NUMCOLS; // whats the row and col when displayed
        int col = i % NUMCOLS;

        // WHAT/WHERE'S THE EMPTY BUTTON?
        int iempty = -1; // which button in the list
        for (int j = 0; j < allButtons.size(); j++) {
            if (allButtons.get(j).getIcon() == null) {
                iempty = j;
                break;
            }
        }
        int rowEmpty = iempty / NUMCOLS; // whats the row and col when displayed
        int colEmpty = iempty % NUMCOLS;

        //// check if the button clicked on is next to the empty button
        if ((row == rowEmpty && Math.abs(col - colEmpty) == 1)
                ||
                (col == colEmpty && Math.abs(row - rowEmpty) == 1)) {
            // SWAP THE TWO BUTTONS
            Collections.swap(allButtons, i, iempty);
            UpdateButtons();
        }
    }

    public void UpdateButtons() {
        mainPanel.removeAll();
        for (var btn : allButtons) {
            mainPanel.add(btn);
        }
        mainPanel.validate();
    }

    public void ResetGame() {
        Collections.shuffle(allButtons);
        UpdateButtons();
    }

    public BufferedImage LoadImage(String filePath) throws IOException {
        return ImageIO.read(new File(filePath));

    }

    public PuzzleGame() {
        setContentPane(mainPanel); // adds the panel to the frame
        mainPanel.setLayout(new GridLayout(NUMROWS, NUMCOLS));// set the grid layout to the panel

        // add menu bar and menu items
        optionMenu.add(numRowsItem);
        optionMenu.add(numColsItem);
        menuBar.add(optionMenu);
        setJMenuBar(menuBar);

        // add reset button and action listener
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(resetButton);
        resetButton.addActionListener(e -> ResetGame());
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        try {
            imageSource = LoadImage("GameImage.jpg");

            // find the height, width of the original image
            int sourceHeight = imageSource.getHeight();
            int sourceWidth = imageSource.getWidth();

            WIDTH = (int) (((double) sourceWidth * HEIGHT) / sourceHeight);// resize window to match image aspect ratio

            // create a resized image to match our window
            imageResized = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_ARGB);// empty canvas
            var g = imageResized.createGraphics();
            g.drawImage(imageSource, 0, 0, WIDTH, HEIGHT, null);
            g.dispose();

        } catch (Exception e) {
            // System.out.println(e.getMessage());
            JOptionPane.showMessageDialog(this, e.getMessage(), "Critial Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        for (int i = 0; i < NUMROWS * NUMCOLS; i++) {
            int row = i / NUMCOLS;
            int col = i % NUMCOLS;

            // get the right slice from scaleImage into the button
            // import java.awt.image.CropImageFilter;
            // import java.awt.image.FilteredImageSource;
            Image imageSlice = createImage(new FilteredImageSource(
                    imageResized.getSource(),
                    new CropImageFilter(col * WIDTH / NUMCOLS, row * HEIGHT / NUMROWS, WIDTH / NUMCOLS,
                            HEIGHT / NUMROWS)));

            FancyButton btn = new FancyButton(); // create a button
            btn.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            allButtons.add(btn);

            if (i == NUMCOLS * NUMROWS - 1) {
                btn.setBorderPainted(false);
                btn.setContentAreaFilled(false);
            } else {
                btn.setIcon(new ImageIcon(imageSlice));
            }
            btn.addActionListener(e -> ClickEventHandler(e));
        }

        Collections.shuffle(allButtons); // will shuffle the buttons
        for (var btn : allButtons) {
            mainPanel.add(btn);
        }
        setTitle("The Puzzle Game - CSC205");
        setSize(WIDTH, HEIGHT);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}

class FancyButton extends JButton {
    public FancyButton() {
        addMouseListener(
                new MouseAdapter() {
                    @Override
                    public void mouseEntered(MouseEvent e) {
                        setBorder(BorderFactory.createLineBorder(Color.YELLOW));
                    }

                    @Override
                    public void mouseExited(MouseEvent e) {
                        setBorder(BorderFactory.createLineBorder(Color.GRAY));
                    }
                });
    }
}