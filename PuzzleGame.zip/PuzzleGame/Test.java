public class Test {

    public static void main(String[] args) throws Exception {
        PuzzleGame game = new PuzzleGame();
    }
}